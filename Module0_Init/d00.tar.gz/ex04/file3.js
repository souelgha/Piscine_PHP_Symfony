function whale()
{
	unicorn();
}
